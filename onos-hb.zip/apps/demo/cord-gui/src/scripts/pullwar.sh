cp $ONOS_ROOT/apps/demo/cord-gui/target/cord-gui-1.2.2-SNAPSHOT.war .
