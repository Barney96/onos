/*
 * Copyright 2014-2015 Open Networking Laboratory
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.onosproject.metrics.topology;

import java.util.List;
import org.onlab.metrics.EventMetric;
import org.onosproject.event.Event;

/**
 * Service interface exported by TopologyMetrics.
 */
public interface TopologyMetricsService {
    /**
     * Gets the last saved topology events.
     *
     * @return the last saved topology events
     */
    List<Event> getEvents();

    /**
     * Gets the Event Metric for the Device Events.
     *
     * @return the Event Metric for the Device Events
     */
    EventMetric topologyDeviceEventMetric();

    /**
     * Gets the Event Metric for the Host Events.
     *
     * @return the Event Metric for the Host Events
     */
    EventMetric topologyHostEventMetric();

    /**
     * Gets the Event Metric for the Link Events.
     *
     * @return the Event Metric for the Link Events
     */
    EventMetric topologyLinkEventMetric();

    /**
     * Gets the Event Metric for the Topology Graph Events.
     *
     * @return the Event Metric for the Topology Graph Events
     */
    EventMetric topologyGraphEventMetric();

    /**
     * Gets the Event Metric for the Topology Graph Reasons Events.
     *
     * @return the Event Metric for the Topology Graph Reasons Events
     */
    EventMetric topologyGraphReasonsEventMetric();
}
